
/**
 *
 * QUESTION 7
 *
 * Mark Alexander
 *
 * 20112145
 *
 * COMP503
 *
 * */


abstract public class Vehicle
{

	public void honk() {
		System.out.println("Honk");
	}
	
	abstract public void model();

}
