
/**
 *
 * QUESTION 4
 *
 * Mark Alexander
 *
 * 20112145
 *
 * COMP503
 *
 * */


public enum Code
{
	Red,Yellow,Green
}
