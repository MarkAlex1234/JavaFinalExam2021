
/**
 *
 * QUESTION 7
 *
 * Mark Alexander
 *
 * 20112145
 *
 * COMP503
 *
 * */

public class Car extends Vehicle
{

	@Override
	public void honk() {
		System.out.println("beep-beep");
	}
	
	
	@Override
	public void model() {
		System.out.println("Car-A");
	}

}
